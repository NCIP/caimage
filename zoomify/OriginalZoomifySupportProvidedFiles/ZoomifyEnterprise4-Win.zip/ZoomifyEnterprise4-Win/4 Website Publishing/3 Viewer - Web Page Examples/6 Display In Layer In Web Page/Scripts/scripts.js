function imageSwap(el,which){
  el.src=el.getAttribute(which || "origsrc");
}

function imageSwapSetup(){
  var x = document.getElementsByTagName("img");
  for (var i=0;i<x.length;i++){
    var oversrc = x[i].getAttribute("oversrc");
    if (!oversrc) continue;    
    x[i].oversrc_img = new Image();
    x[i].oversrc_img.src=oversrc;
    x[i].onmouseover = new Function("imageSwap(this,'oversrc');");
    x[i].onmouseout = new Function("imageSwap(this);");
    x[i].setAttribute("origsrc",x[i].src);
  }
}

function windowOpen(filename,windowname,properties) {
    mywindow = window.open(filename,windowname,properties);
}

var preloadImageSwap =(window.onload)? window.onload : function(){};
window.onload = function(){preloadImageSwap(); imageSwapSetup();}





//-----------------reset size----------------------

var screenWidth = 0;
var screenHeight = 0;
var imageWidth = 0;
var imageHeight = 0;
var BorderType = '';


function GetWindowSize() {
  if (typeof(window.innerWidth ) == 'number') {
    screenWidth = window.innerWidth;
    screenHeight = window.innerHeight;
    }
  else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
    screenWidth = document.documentElement.clientWidth;
    screenHeight = document.documentElement.clientHeight;
    }
  else if (document.body && (document.body.clientWidth || document.body.clientHeight)) {
    screenWidth = document.body.clientWidth;
    screenHeight = document.body.clientHeight;
    }
  else
    GetScreenSize();
}

function GetScreenSize() {
  if (self.screen) {
    screenWidth = screen.width;
    screenHeight = screen.height;
    }
  else if (self.java) {
    dtk = java.awt.Toolkit.getDefaultToolkit();
    ss = dtk.getScreenSize();
    screenWidth = ss.width;
    screenHeight = ss.height;
    }
  else if (self.theBody) {
    screenWidth = theBody.offsetWidth;
    screenHeight = theBody.offsetHeight;
    }
  else {
    screenWidth = 800;
    screenHeight = 600;
    }
}

function resetSize(percent) {

  GetWindowSize();
  
  if(percent >90){
    percent = 90;
  }
  
  tempWidth = Math.round(screenWidth * percent / 100);
  tempHeight = Math.round(screenHeight * percent / 100);
  imageWidth = tempWidth;
  imageHeight = tempHeight;
}



//-----------------create & delete layer----------------------

function getInternetExplorerVersion() {
	var rv = -1; 
	if (navigator.appName == 'Microsoft Internet Explorer') {
		var ua = navigator.userAgent;
		var re  = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
		if (re.exec(ua) != null)
		rv = parseFloat( RegExp.$1 );
	}
	return rv;
}

function getViewerIfIEElseNullify() {
	if(getInternetExplorerVersion() != -1) {
		return "ZoomifyAnnotationViewer.swf";
	} else {
		//return ""; Modified for FF 3.5
		return "ZoomifyAnnotationViewer.swf";		
	}
}

function showLayerIfIEOrCreate(id, xPos, yPos, viewerPath, flashVarsString, visibleOrNot) {
	if(getInternetExplorerVersion() == -1) {
		createLayerInnerHTML(id, xPos, yPos, viewerPath, flashVarsString, visibleOrNot)
	} else {
		if(visibleOrNot == 'show') { visibleOrNot = 'visible'; }
		if(visibleOrNot == 'hide') { visibleOrNot = 'hidden'; }
		document.getElementById(id).style.visibility = visibleOrNot; return false;
	}
}

var oldInnerHTML = "";

function createLayerInnerHTML(layerID, xCenterPos, yTopPos, viewerPath, flashVarsString, visibleOrNot) {
	if(oldInnerHTML != "") { restoreInnerHTML(); }
	oldInnerHTML = document.body.innerHTML;
	document.body.innerHTML=document.body.innerHTML 
	+'\n<table width="712" border="0" cellspacing="0" cellpadding="0" align="CENTER">'
	+'\n<tr>'
	+'\n<td>'
	+'\n<div class="noprint">'
	+'\n<div class="noindex">'
	+'\n<div id='+layerID+' style="visibility: '+visibleOrNot+'; position: absolute; margin-left: auto; margin-right: auto; center: '+xCenterPos+'px; top: '+yTopPos+'px; width: 712; height: 350;">'
	+'\n<div style="height: 20px; margin-left: 0px; position: absolute; top: -25px; right: 0px;"><a href="#" onclick="javascript:restoreInnerHTML()"><img src="Scripts/btnClose-666666.gif" width="68" height="20" border="0" style="display: block; vertical-align: top;" /></a>'
	+'\n</div>'
	+'\n<TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0 BGCOLOR=#cccccc WIDTH="712" ALIGN="CENTER">'
	+'\n<TR>'
	+'\n<TD>'
	+'\n<TABLE BORDER=0 WIDTH=100% BGCOLOR=#ffffff CELLSPACING=0 CELLPADDING=0>'
	+'\n<TR>'
	+'\n<TD>'		
	+'\n<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,47,0" id="theMovie" width="712" height="350" >'
	+'\n<param name="FlashVars" value="'+flashVarsString+'">'
	+'\n<PARAM NAME=Menu VALUE="FALSE">'
	+'\n<param name="src" value='+viewerPath+'>'
	+'\n<embed flashvars="'+flashVarsString+'" src='+viewerPath+' MENU="false" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" name="theMovie" width="712" height="350" ></embed>'
	+'\n</object>'
	+'\n</TD>'
	+'\n</TR>'
	+'\n</TABLE>'
	+'\n</TD>'
	+'\n</TR>'
	+'\n</TABLE>'
	+'\n</div>'
	+'\n</div>'
	+'\n</div>'
	+'\n</td>'
	+'\n</tr>'
	+'\n</table>'
}

function restoreInnerHTML() {
	if(oldInnerHTML != "") {
		document.body.innerHTML = oldInnerHTML;
	}
}


