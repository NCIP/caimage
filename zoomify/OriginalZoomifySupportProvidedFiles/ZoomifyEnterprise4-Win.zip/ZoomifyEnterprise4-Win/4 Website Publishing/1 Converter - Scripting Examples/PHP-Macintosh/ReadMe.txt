The php is called with ?file=/relative/path/to/image/to/convert

On Windows, you should only need to put the Enterprise encoder in the same folder as the php and call it Zoomifyer.exe.

On a Mac, you will need to add the attached Zoomifyer.exe file � which is actually an AppleScript that converts the path name that is in the Zoomifyer.temp file from a UNIX path to a Mac path and then launches the encoder named Zoomifyer Enterprise v3.0.app.  Note that Zoomifyer.exe is actually AppleScript and can be loaded into and modified using Script Editor.

Note that on both Mac and Windows, folder permissions must be set to properly allow the script to run and the app to launch.