<?php
/**
 * @author Andrew S. Garbutt <asgarbutt@ucdavis.edu>
 * @version v 1.5 upload.php, 2003/12/10
 * @dependancies PHP 4.3.0 or greater
 * @copyright Copyright &copy; 2003, Andrew S. Garbutt
 *
 * Purpose:  Designed to mimic the functionality of
 * 			 Zoomify, Inc. upload.asp file. Grabs POST
 *			 and GET XML data from the Zoomify Annotator
 *			 and writes it to an XML file.
 *
 * Note: This code is released with no expressed or written warranty.
 */

function parseXML($HTTP_RAW_POST_VARS, $HTTP_GET_VARS)
{
	$strXML=$HTTP_RAW_POST_VARS;

	//escapeXML($strXML); // Escape the appropriate characters to avoid database complications.

	$fileName=$HTTP_GET_VARS["file"]; // The filename is passed in the GET namespace, this is how and where we get it.

	if ($fileName!="")  // If the file name is not an empty string
	{
		 /**
		  * This is an initial attempt that does not work because 'DOCUMENT_ROOT' is undefined on IIS.
		  *
		  * $fullPath=$_SERVER['DOCUMENT_ROOT'].$fileName;  // Gets the document root and appends the GET VAR "file".
		  **/

		/**
		 * This is another method that does not work.  It makes too many assumptions about the server environment.
		 * realpath("."), as it is used here, returns the path to the directory where the php file is located.
		 * However, the value of $fileName is relative to the root of the server (i.e. "/zas/xml/xmlfile.xml").
		 * If we were to append these two variables we would get:
		 *    C:\Server\DocumentRoot\zas\xml/zas/xml/xmlfile.xml
		 * Therefore, we must match the paths and trim what is not needed or use another method.
		 *
		 * $theLocalPath=realpath(".");
		 * $fullPath=$theLocalPath.$fileName;  // Gets the document root and appends the GET VAR "file".
		 **/

		/**
		 * This method should work on all servers that are supported by PHP.  Here we have PHP defined super globals
		 * that should be defined on all platforms supported by PHP.  We then create a substring starting from the
		 * character position "0" to the position minus the length of the executed script (relative to the server root).
		 * Lastly, we append the $fileName passed from the swf.
		 **/
		$fullPath = substr($_SERVER['SCRIPT_FILENAME'], 0, -strlen($_SERVER['SCRIPT_NAME'])).$fileName;

		// report($HTTP_POST_VARS, $fullPath);  // Usefull for debugging.

		if (file_exists($fullPath)) // Check first to make sure file exists.
		{
			if (is_writeable($fullPath))  // Check to make sure that the file can be written to.
			{
				if (!$objFSOFile=fopen($fullPath, "w")) // Opens the file $fullPath for writing.
				{
					echo "Cannot open file ($fileName)";
				}

				fwrite($objFSOFile, $strXML); // Dumps the string $strXML into the file.

				/**
				 * This is redudant as fclose should flush the file before closing.  Further, we are not
				 * opening the file with an append flag and we are not opening a socket.  We are opening,
				 * then writing string data, then closing imeadiately.
				 *
				 * fflush($objFSOFile);
				 **/

				fclose($objFSOFile); // Closes the $fullPath file.

				echo "File saved to server successfully"; // writes out to response a success.
			}
			else
			{
				echo "File ($fileName) is not writeable.";
			}
		}
		else  // If the file does not exist...  there is no data to put into the file, thus we must put a blank template for next time.
		{
			if (!$objFSOFile=fopen($fullPath, "w")) // Opens the file $fullPath for writing.
			{
				echo "Cannot open file ($fileName)";
			}

			fwrite($objFSOFile, $strXML); // Dumps the string $strXML into the file.

			/**
			 * This is redudant as fclose should flush the file before closing.  Further, we are not
			 * opening the file with an append flag and we are not opening a socket.  We are opening,
			 * then writing string data, then closing imeadiately.
			 *
			 * fflush($objFSOFile);
			 **/

			fclose($objFSOFile); // Closes the $fullPath file.

			echo "New file saved to server successfully"; // writes out to response a success.
		}
	}
	else
	{
		echo "Error saving file ($fileName) on server"; // writes out to response a failure.
	}
}

function escapeXML($xml)
{
	// Replace methods, should be self explanitory
	$xml = str_replace("\\", "", $xml);
	$xml = str_replace("\r", " ", $xml);
	$xml = str_replace("\n", "", $xml);
	$xml = str_replace(">", ">\n", $xml);

	return $xml; // Return the escaped xml
}

// This is handy for error reporting.
function report($HTTP_RAW_POST_DATA, $error)
{
	$fileHandle = fopen("C:\phperror.txt", "w");  // Be sure to change this to an appropriate dir for your system.
	$reportStr = "_SERVER['SCRIPT_FILENAME'] = ".$_SERVER['SCRIPT_FILENAME']."\n"
				."_SERVER['SCRIPT_NAME'] = ".$_SERVER['SCRIPT_NAME']."\n"
				."_SERVER['DOCUMENT_ROOT'] = ".$_SERVER['DOCUMENT_ROOT']."\n"
				."fullPath = ".$error."\n"
				."\n".$HTTP_RAW_POST_DATA."\n";

	fputs($fileHandle, $reportStr);
	fclose($fileHandle);
}

// Call our main function
parseXML($HTTP_RAW_POST_DATA, $HTTP_GET_VARS);
?>

