<?php
/*****
 * @author Mirek Kasper <mirqu@interia.pl, mirek@zoomify.pl>
 * @version v 1.0 xmlRepair.php, 2003/12/17
 * @dependancies PHP 4.3.0 or greater
 * @copyright Copyright &copy; 2003, Mirek Kasper
 *
 * Purpose:  Designed to convert string in upload.php for Zoomify to correct XML format
 *
 *****/

// Make $strXML an xml format
function repairXML($strXML)
{
	while(strpos($strXML,"POI_x") == true)
	{
		$pos = strpos($strXML,"POI_x");
		$strXML{$pos+3} = ' ';
	}
	while(strpos($strXML,"Note_text") == true)
	{
		$pos = strpos($strXML,"Note_text");
		$strXML{$pos+4} = ' ';
	}
	while(strpos($strXML,"Label_x") == true)
	{
		$pos = strpos($strXML,"Label_x");
		$strXML{$pos+5} = ' ';
	}
	return $strXML;
}
?>
