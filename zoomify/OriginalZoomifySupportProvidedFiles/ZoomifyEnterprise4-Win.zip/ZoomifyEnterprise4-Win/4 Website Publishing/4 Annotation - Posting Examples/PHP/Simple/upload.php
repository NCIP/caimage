<?php
$post="";
$ph=fopen("php://input", "rb");
   while (!feof($ph)) {
      $post .= fread($ph, 4096);
   }
fclose($ph);

$filename = $HTTP_GET_VARS['file'];
$uploaddir = '/srv/www/htdocs';
if($filename){
    $uploadfile = $uploaddir . $filename;

    $fp = fopen($uploadfile, "w+");
     if($fp) {
       fputs($fp, $post);
       fclose($fp);
       echo "Saved $filename";
   }
   else{
       echo "Failed to save $filename";
   }
}
?>
