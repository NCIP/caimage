#!/usr/bin/perl
# 2005 04 20 - Per Krogh Nielsen / danweb.com
# Usage: wrapper.pl <source> <dest>
#
# <source> :  sourceimage - FULL path eg: /var/www/html/images/large/bicycle.jpg
# <dest>   :  destdir - FULL path     eg: /var/www/html/images/zoomified/bicycle

require("slice.pl");
$fault = slice("$ARGV[0]","$ARGV[1]");
warn $fault if $fault;

