<?php

// test

//print zslicer("C:/Projects/z/TestZConverter/081501.jpg") . "\n";
//print zslicer("C:/Projects/z/TestZConverter/City003.jpg") . "\n";
//print zslicer("C:/Projects/z/TestZConverter/Uu_male_head.jpg") . "\n";
//print zslicer("C:/Projects/z/TestZConverter/carmel.jpg") . "\n";
//print zslicer("C:/Projects/z/TestZConverter/exact.gif") . "\n";
//print zslicer("C:/Projects/z/TestZConverter/justover.gif") . "\n";

//print "layer for 183 = " . strval(calc_layer_num(183)) . "\n";
//print "layer for 500 = " . strval(calc_layer_num(500)) . "\n";
//print "layer for 1028 = " . strval(calc_layer_num(1028)) . "\n";
//print "layer for 3008 = " . strval(calc_layer_num(3008)) . "\n";
//print "layer for 512 = " . strval(calc_layer_num(512)) . "\n";
//exit;

/*****************************************************************************
*
* Name: zslicer.php
*
* Author: Mike McGary mcgary@avacata.com
* Created: July, 14, 2005
*
* Purpose: preprocesses an image to prepare it for use with the
*          Zoomify flash component (www.zoomify.com).  Needs php and
*          the GD library.
*
* URL Parameters:
*
*          filepath = path and name of image file to process. Resulting directory
*                     of processed image pieces will be in the filename (minus path and
*                     file extension)
*
*          returns string indicating success/failure.
*
*		(c) 2005 Avacata Inc.  All rights reserved.
*
******************************************************************************
* Change Log:
*
* Version    Date       Programmer
* ------- -------- ------------------
*    1.0   07/14/05 Mike McGary
*    - Created
*
******************************************************************************
* CVS ID
******************************************************************************
*    $Id:  $
*    $Name:  $
*****************************************************************************/

/*****************************************************************************
 * Name: zslicer
 *
 * Author: Mike McGary
 *
 * Purpose: slice up the image and put into directory with xml marker
 *
 * Parameters:
 *
 * Returns: string.  empty string means success.  Otherwise, error string
 *
*****************************************************************************/
function zslicer($filepath) {

  $results = "";
  $dirname = dirname($filepath);
  $fileext = substr($filepath, strrpos($filepath, '.'));
  $filename = basename(strval($filepath), $fileext);

  $upperdir = $dirname . "/" . $filename;
  $lowerdir = $upperdir . "/TileGroup0";

  $width = 0;
  $height = 0;
  $type = 0;
  $attr = "";
  $numtiles = 0;

  // layers is a 0-based index to indicate the slice layers.  0-0-0.jpg is all the
  // images in the 0'th layer.  1-0-0.jpg ... 1-x-y.jpg are layer 1, etc.
  $layers = 0;

  //print "filepath = $filepath\n";
  //print "dirname = $dirname\n";
  //print "fileext = $fileext\n";
  //print "filename = $filename\n";

  // check to see if image file exists
  if (!file_exists($filepath))
  {
    return "file [" . $filepath . "] does not exist.";
  }

  // check to see if this is a real image...loading it in the process
  list($width, $height, $type, $attr) = getimagesize("$filepath");

  if ($width == 0 || $height == 0)
  {
    return "file [" . $filepath . "] could not be opened as an image.";
  }

  switch ($type)
  {
      case 1:  // GIF
        $origimage = @imagecreatefromgif($filepath);
        if (!$origimage)
        {
          return "file [" . $filepath . "] is not a valid GIF file.";
        }
        break;
      case 2:  // JPG
        $origimage = @imagecreatefromjpeg($filepath);
        if (!$origimage)
        {
          return "file [" . $filepath . "] is not a valid JPEG file.";
        }
        break;
      case 3:  // PNG
        $origimage = @imagecreatefrompng($filepath);
        if (!$origimage)
        {
          return "file [" . $filepath . "] is not a valid PNG file.";
        }
        break;
      default:
        return "file [" . $filepath . "] is image type $type, which is not recognized.";
  }

  $layers = max(calc_layer_num($width),calc_layer_num($height));

  $curlayer = $layers;

  // create dir tree

  @mkdir($upperdir, 0777);
  @mkdir($lowerdir, 0777);

  $curwidth = $width;
  $curheight = $height;
  $curimage = $origimage;

  while ($curlayer >= 0)
  {
    $col = 0;
    $curx = 0;

    while ($curx < $curwidth)  // each column
    {
      $cury = 0;
      $row = 0;
      $slicewidth = min(256, $curwidth - $curx);

      while ($cury < $curheight)  // row entry
      {
        $sliceheight = min(256, $curheight - $cury);
        //print "layer $curlayer - $col - $row - $sliceheight - $slicewidth \n";

        $newimage = imagecreatetruecolor($slicewidth, $sliceheight);
        imagecopyresampled($newimage, $curimage, 0, 0, $curx, $cury, $slicewidth, $sliceheight, $slicewidth, $sliceheight);
        imagejpeg($newimage, $lowerdir . "/" . $curlayer . "-" . $col . "-" . $row . ".jpg", 75);
        imagedestroy($newimage);
        $numtiles = $numtiles + 1;
        $cury = $cury + 256;
        $row = $row + 1;
      }
      $curx = $curx + 256;
      $col = $col + 1;
    }

    if ($curlayer > 0)
    {
      // shrink image in half
      $newwidth = $curwidth / 2;
      $newheight = $curheight / 2;
      $newimage = imagecreatetruecolor($newwidth, $newheight);
      imagecopyresampled($newimage, $curimage, 0, 0, 0, 0, $newwidth, $newheight, $curwidth, $curheight);
      imagedestroy($curimage);
      $curimage = $newimage;
      $curwidth = $newwidth;
      $curheight = $newheight;
    }
    $curlayer = $curlayer - 1;
  }

  imagedestroy($curimage);

  write_xml_image_properties($width, $height, $numtiles, $upperdir);

  return $results;
}

function calc_layer_num($size) {
  $layer = 0;
  $newsize = $size;

  while (true)
  {
    if ($newsize <= 256)
    {
      return $layer;
    }
    $newsize = $newsize / 2;
    $layer = $layer + 1;
  }
}

function write_xml_image_properties($width, $height, $numtiles, $dir)
{
   $handle = fopen($dir . "/ImageProperties.xml", "w");
   fputs($handle,'<IMAGE_PROPERTIES WIDTH="' . $width . '" HEIGHT="' . $height . '" NUMTILES="' . $numtiles . '" NUMIMAGES="1" VERSION="1.8" TILESIZE="256" />');
   fclose($handle);
}
?>
