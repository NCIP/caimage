<?php

###############################################################################
#
# image_slicer.php
#
# Based loosely on slice.pl, which was provided with the following copyright info
#
# ----------------------------------------------------------------------------
# Copyright (c) W.S. Packaging, Inc.          -- www.wspackaging.com
# Business & Marketing Development Department -- webflex(AT)wspackaging.com
# This code is free to use and extend, providing this seven-line copyright
# message remain intact. No warranties are given, expressed or implied.
# Go Packers.
# ----------------------------------------------------------------------------
#
###############################################################################

if( !class_exists( 'image_slicer' )){
class image_slicer{

const output_quality = 80;
const default_tile_size = 256;
const tiles_per_group = 256;
const level_scale_factor = 2;
const resize_function = 'imagecopyresampled';//the faster, lower-quality option is imagecopyresized

# do not change tile_size Zoomify Viewers modified to support change.
public static function slice( $image_path, $output_path, $tile_size=self::default_tile_size ){
	//let this script go for 60 sec instead of the default
	set_time_limit( 60 );
	//make sure the input is an image
	if( !$size = getImageSize( $image_path ))
		return trigger_error( __CLASS__.'::'.__FUNCTION__."$image_path is not an image; aborting slice!", E_USER_ERROR );
	list( $osrc_w, $osrc_h, $osrc_type, $osrc_attr ) = $size;

	//make sure the output dir exists
	if( !is_dir( $output_path ) )
		return trigger_error( __CLASS__.'::'.__FUNCTION__.": output path $output_path does not exist; aborting slice", E_USER_ERROR );

	//make sure the output dir is writeable
	if( !is_writeable( $output_path ) )
		return trigger_error( __CLASS__.'::'.__FUNCTION__.": output path $output_path is not writeable; aborting slice", E_USER_ERROR );

	# find out how many levels of chopping we will need to do. in other words,
	# how many downscales does it take to get to something smaller than
	# $tile_size?
	$levels = ceil( log( max( $osrc_w, $osrc_h ), self::level_scale_factor )) - log( $tile_size, self::level_scale_factor );

	$tile_index=0;
	$orig_source_img = ImageCreateFromJPEG( $image_path );
	$resize_function = self::resize_function;
	for( $level = $levels; $level >= 0; $level--) {
		//first get source image and size
		if( $level == $levels ) {
			$source_img = $orig_source_img;
			$base_img = $orig_source_img;
			$scale_w = $osrc_w;
			$scale_h = $osrc_h;
		} else {
			//use the base image from previous level as the source for this level
			if( $base_img != $source_img ){
				//free up some memory
				imagedestroy( $source_img );
			}
			$source_img = $base_img;
			$src_w = $scale_w;
			$src_h = $scale_h;

			//next get the scaled base image
			$scale = pow( self::level_scale_factor, $level-$levels );
			$scale_w = round( $scale * $osrc_w );
			$scale_h = round( $scale * $osrc_h );
			$base_img = ImageCreateTrueColor( $scale_w, $scale_h );
			$resize_function( $base_img, $source_img, 0, 0, 0, 0, $scale_w, $scale_h, $src_w, $src_h);
		}

		if( $level > 0 ){
			//now slice
			$cols = ceil( $scale_w/$tile_size );
			$rows = ceil( $scale_h/$tile_size );
			for( $col = 0; $col < $cols; $col++ ){
				$start_x = $col * $tile_size;
				$stop_x = min( $scale_w, $start_x + $tile_size ) - 1;
				$tile_width = $stop_x - $start_x + 1;
				//echo "level=$level, col=$col, start_x=$start_x, stop_x=$stop_x, tile_width=$tile_width";
				for( $row = 0; $row < $rows; $row++ ){
					$start_y = $row * $tile_size;
					$stop_y = min( $scale_h, $start_y + $tile_size ) - 1;
					$tile_height = $stop_y - $start_y + 1;
					//echo "row=$row, start_y=$start_y, stop_y=$stop_y, tile_height=$tile_height";

					$tile = imagecreatetruecolor( $tile_width, $tile_height );
					if( imagecopy( $tile, $base_img, 0, 0, $start_x, $start_y, $tile_width, $tile_height )){
						self::save_tile( $tile, $output_path, $level, $col, $row, $tile_index++ );
					}
				}
			}
		} else self::save_tile( $base_img, $output_path, $level, 0, 0, $tile_index++ );
	}
	$xml_contents = <<<EOD
<IMAGE_PROPERTIES WIDTH="$osrc_w" HEIGHT="$osrc_h" NUMTILES="$tile_index" NUMIMAGES="1" VERSION="1.8" TILESIZE="$tile_size" />
EOD;
	file_put_contents ( "$output_path/ImageProperties.xml", $xml_contents );
}

protected static function save_tile( $tile, $base_path, $level, $col, $row, $tile_index ){
	$path = "$base_path/TileGroup". floor( $tile_index / self::tiles_per_group );
	if( $tile_index % self::tiles_per_group == 0 ) mkdir( $path );
	$file_path = "$path/$level-$col-$row.jpg";
	imagejpeg( $tile, $file_path, self::output_quality );
}

}//class


}//ifndef
?>
