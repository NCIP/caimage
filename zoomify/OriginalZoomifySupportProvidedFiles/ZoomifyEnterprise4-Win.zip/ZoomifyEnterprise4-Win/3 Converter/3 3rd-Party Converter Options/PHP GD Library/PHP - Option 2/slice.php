#! /opt/lampp/bin/php
# /usr/bin/php
<?php

//need to find the image slicer
//first check in the same dir as me
$image_slicer = dirname( __FILE__ ).'/image_slicer.php';
if( file_exists( $image_slicer )) require( $image_slicer );
//else leave it up to include_path directive
else require( 'image_slicer.php' );

//if we get this far, we have an image_slicer
if( $argv[1] == '-h' ){
	echo <<<EOD
Help:
arg1: full path of image to be sliced
arg2: ouput directory (must already exist)

EOD;
return;
}

image_slicer::slice( $argv[1], $argv[2] );
?>
