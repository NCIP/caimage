I needed a class to process a source directory of mixed
files (images and other media) and write the zoomify
directories to a separate destination directory. So I
wrote one.

Donald Ball 
donald.ball@nashville.gov