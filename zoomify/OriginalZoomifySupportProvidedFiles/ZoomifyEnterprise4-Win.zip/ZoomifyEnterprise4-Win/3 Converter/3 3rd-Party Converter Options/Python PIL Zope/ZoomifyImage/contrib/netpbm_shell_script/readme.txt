
To use need.

pbmtools. The debian package is called - netpbm

Run the script with

./zoomifyimage.sh inputfile.jpg

It only supports jpg input at the moment. 

It will create a folder with the same name as the file (less the .jpg).
Inside the folder will be the tiles, and the xml file 

In the same folder as where run, it will create a html sub file that can
be used directly to make use of the tiles.

You just have to copy into the same folder as the html file, the
zoomifyViewer.swf file.

Fran Firman
ffirman@netgate.net.nz